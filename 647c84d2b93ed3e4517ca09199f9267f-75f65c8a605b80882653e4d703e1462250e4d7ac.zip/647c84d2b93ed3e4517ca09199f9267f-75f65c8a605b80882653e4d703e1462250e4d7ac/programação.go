package main

import "fmt"

func main() {
	var num1, num2, num3 int
	fmt.Println("digite um número:")
	fmt.Scan(&num1)
	fmt.Println("digite outro número:")
	fmt.Scan(&num2)
	fmt.Println("agora digite o ultimo número:")
	fmt.Scan(&num3)
	soma := num1 + num2 + num3
	fmt.Printf("a soma entre os números %d,%d e %d é %d", num1, num2, num3, soma)
}
